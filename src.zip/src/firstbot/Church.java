package firstbot;
import btcutils.*;

public class Church extends Unit {

    public Church(MyRobot myRobot){
        super(myRobot);
    }

    @Override
    public Action turn(){
        return null;
    }

}
