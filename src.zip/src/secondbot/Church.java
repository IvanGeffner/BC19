package secondbot;
import btcutils.Action;

public class Church extends Unit {

    public Church(MyRobot myRobot){
        super(myRobot);
    }

    @Override
    public Action turn(){
        return null;
    }

}
