package secondbot;
import btcutils.*;

public class Prophet extends Unit {

    public Prophet(MyRobot myRobot){
        super(myRobot);
    }

    @Override
    public Action turn(){
        return null;
    }

}
