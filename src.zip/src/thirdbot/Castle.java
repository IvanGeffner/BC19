package thirdbot;
import btcutils.Action;

public class Castle extends Unit {

    public CastleUtils castleUtils;
    int objective;

    public Castle (MyRobot myRobot){
        super(myRobot);
        castleUtils = new CastleUtils(myRobot);
        objective = 0;
    }

    @Override
    public Action turn(){
        castleUtils.update();
        if (castleUtils.shouldBuildPilgrim()) {
            for (int objective = 0; objective < castleUtils.objectives.length; ++objective) {
                int occ = castleUtils.isOccupied(objective);
                if (occ == Constants.FREE) {
                    castleUtils.createPilgrim(objective);
                    break;
                } else if (occ == Constants.PARTIALLLY_OCCUPIED) break;
            }
        }
        return castleUtils.nextTurnAction;
    }

}
