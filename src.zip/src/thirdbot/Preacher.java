package thirdbot;

import btcutils.Action;

public class Preacher extends Unit {

    public Preacher(MyRobot myRobot){
        super(myRobot);
    }

    @Override
    public Action turn(){
        return null;
    }

}
