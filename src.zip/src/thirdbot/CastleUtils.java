package thirdbot;

import btcutils.Action;
import btcutils.Robot;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class CastleUtils {


    MyRobot myRobot;
    boolean hSim;
    boolean vSim;
    Utils utils;
    Location myLocation;
    Action nextTurnAction = null;


    Objective[] objectives;
    int[] karbo;
    int[] fuel;
    int[] enemyCastles;

    int[] XOccupied, YOccupied;
    Location[] targetByID;
    PilgrimInfo[][] pilgrimInfoMap;

    int churchRequiredCont = 0;


    public CastleUtils(MyRobot myRobot){
        this.myRobot = myRobot;
        hSim = vSim = true;
        utils = new Utils(myRobot);
        myLocation = new Location(myRobot.me.x, myRobot.me.y);
        objectives = null;
        initializePilgrimInfo();
    }

    void update(){
        utils.update();
        if (objectives == null) generateObjectiveList();
        updatePilgrimInfo();
        nextTurnAction = null;
    }

    boolean createPilgrim(int objectiveIndex){
        int dir = objectives[objectiveIndex].dir;
        if (!utils.canBuild(Constants.PILGRIM)) return false;
        for (int i = 0; i < Constants.rad2Index; ++i){
            if (utils.isEmptySpace(Constants.X[dir], Constants.Y[dir])){
                nextTurnAction = myRobot.buildUnit(Constants.PILGRIM, Constants.X[dir], Constants.Y[dir]);
                /*TODO check resources*/
                sendMiningLocation(objectiveIndex, dir);
                return true;
            }
            ++dir;
            if (dir >= Constants.rad2Index) dir = 0;
        }
        return false;
    }

    void sendMiningLocation(int objectiveIndex, int dir){
        int rad = Constants.Steplength[dir];
        int message = ((objectives[objectiveIndex].x* Constants.maxMapSize) + objectives[objectiveIndex].y);
        signalWithRound(message, rad);
    }

    void signalWithRound(int message, int rad){
        message = (((myRobot.me.turn)%2)*Constants.LocationSize + message);
        myRobot.signal(message, rad);
    }


    void generateObjectiveList(){
        int[][] dist = new int[utils.dimX][utils.dimY];
        int[][] dir = new int[utils.dimX][utils.dimY];
        int[][] fuelM = new int[utils.dimX][utils.dimY];
        dist[myLocation.x][myLocation.y] = 1;
        Queue<Location> queue = new LinkedList<>();
        queue.add(myLocation);
        ArrayList<Objective> aux = new ArrayList<>();
        int karboCont = 0, fuelCont = 0;
        while (!queue.isEmpty()){
            Location last = queue.poll();
            int lastDist = dist[last.x][last.y];
            if (myRobot.fuelMap[last.y][last.x]){
                aux.add(new Objective(Constants.OBJ_FUEL, lastDist-1, last.x, last.y, dir[last.x][last.y]));
                ++fuelCont;
            }
            if (myRobot.karboniteMap[last.y][last.x]){
                aux.add(new Objective(Constants.OBJ_KARBO, lastDist-1, last.x, last.y, dir[last.x][last.y]));
                ++karboCont;
            }
            int limit = Constants.rad4Index;
            if (lastDist == 1) limit = Constants.rad2Index;
            for (int i = 0; i < limit; ++i){
                int newX = last.x + Constants.X[i];
                int newY = last.y + Constants.Y[i];
                int newFuel = fuelM[last.x][last.y] + Constants.Steplength[i];
                if (utils.isInMap(newX, newY) && utils.isEmptySpaceAbsolute(newX, newY)){
                    if (dist[newX][newY] == 0){
                        queue.add(new Location(newX, newY));
                        dist[newX][newY] = lastDist + 1;
                        fuelM[newX][newY] = newFuel;
                        if (lastDist == 1) dir[newX][newY] = i;
                        else dir[newX][newY] = dir[last.x][last.y];
                    }
                    if (dist[newX][newY] == lastDist + 1){
                        if (fuelM[newX][newY] > newFuel){
                            fuelM[newX][newY] = newFuel;
                            if (lastDist == 1) dir[newX][newY] = i;
                            else dir[newX][newY] = dir[last.x][last.y];
                        }
                    }
                }
            }
        }
        objectives = aux.toArray(new Objective[aux.size()]);
        karbo = new int[karboCont];
        fuel = new int[fuelCont];
        int indKarbo = 0, indFuel = 0;
        for (int i = 0; i < objectives.length; ++i){
            if (objectives[i].type == Constants.OBJ_KARBO) karbo[indKarbo++] = i;
            if (objectives[i].type == Constants.OBJ_FUEL) fuel[indFuel++] = i;
        }
    }

    boolean shouldBuildPilgrim(){
        if (myRobot.karbonite - churchRequiredCont*Constants.karboCosts[Constants.CHURCH] < Constants.karboCosts[Constants.PILGRIM]) return false;
        if (myRobot.fuel - churchRequiredCont*Constants.fuelCosts[Constants.CHURCH] < Constants.fuelCosts[Constants.PILGRIM] + Constants.SAFETY_FUEL) return false;
        return true;
    }

    void initializePilgrimInfo(){
        pilgrimInfoMap = new PilgrimInfo[utils.dimX][utils.dimY];
        targetByID = new Location[Constants.MAX_ID];
    }

    void updatePilgrimInfo(){
        XOccupied = new int[utils.dimX];
        YOccupied = new int[utils.dimY];
        churchRequiredCont = 0;
        for (Robot r : utils.robotsInVision){
            if (r.castle_talk > 0){
                int mes = (r.castle_talk-1)/Constants.maxMapSize;
                if (mes == 1) ++churchRequiredCont;
                int locInfo = (r.castle_talk-1)%Constants.maxMapSize;
                updatePilgrimInfo(r.id, locInfo, myRobot.me.turn%2);
            }
        }
    }

    void updatePilgrimInfo(int id, int partialLoc, int turn){
        Location loc = targetByID[id];
        if (loc == null) loc = new Location(-1, -1);
        if (turn == 0){
            if (loc.x == -1){
                loc.x = partialLoc;
                if (loc.y == -1) ++XOccupied[loc.x];
            } else if (loc.x != partialLoc) {
                if (loc.y != -1) pilgrimInfoMap[loc.x][loc.y] = null;
                loc.x = partialLoc;
                loc.y = -1;
                ++XOccupied[loc.x];
            }
        } else{
            if (loc.y == -1){
                loc.y = partialLoc;
                if (loc.x == -1) ++YOccupied[loc.y];
            } else if (loc.y != partialLoc) {
                if (loc.x != -1) pilgrimInfoMap[loc.x][loc.y] = null;
                loc.y = partialLoc;
                loc.x = -1;
                ++YOccupied[loc.y];
            }
        }
        targetByID[id] = loc;
        if (loc.x != -1 && loc.y != -1){
            pilgrimInfoMap[loc.x][loc.y] = new PilgrimInfo(id, myRobot.me.turn);
        }
    }


    int isOccupied(int objectiveIndex){
        Objective obj = objectives[objectiveIndex];
        if (XOccupied[obj.x] > 0 || YOccupied[obj.y] > 0) return Constants.PARTIALLLY_OCCUPIED;
        PilgrimInfo pi = pilgrimInfoMap[obj.x][obj.y];
        if (pi != null && pi.lastTurnReporting + Constants.MAX_TURNS_REPORTING > myRobot.me.turn) return Constants.OCCUPIED;
        return Constants.FREE;
    }

    void printObjectives(){
        for (int i = 0; i < utils.dimX; ++i){
            for (int j = 0; j < utils.dimY; ++j){
                PilgrimInfo pi = pilgrimInfoMap[i][j];
                if (pi != null)myRobot.log("Robot with id " + pi.id + " is going to " + i + " " + j);
            }
        }
    }

    class Objective{
        int type, dist, x, y, dir;

        public Objective (int type, int dist, int x, int y, int dir){
            this.type = type;
            this.dist = dist;
            this.x = x;
            this.y = y;
            this.dir = dir;
        }
    }

    class PilgrimInfo{
        int id, lastTurnReporting;

        public PilgrimInfo(int id, int lastTurnReporting){
            this.id = id;
            this.lastTurnReporting = lastTurnReporting;
        }

    }
}
