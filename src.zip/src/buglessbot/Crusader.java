package buglessbot;
import btcutils.*;

public class Crusader extends Unit {

    public Crusader(MyRobot myRobot){
        super(myRobot);
    }

    @Override
    public Action turn(){
        return null;
    }

}
