package buglessbot;
import btcutils.*;

public class Preacher extends Unit {

    public Preacher(MyRobot myRobot){
        super(myRobot);
    }

    @Override
    public Action turn(){
        return null;
    }

}
